### Hexlet tests and linter status:
[![Actions Status](https://github.com/zitaker/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/zitaker/python-project-49/actions)

Welcome to the Brain Games!
brain-even https://asciinema.org/a/6HJt3Ie4gzkVnm7Mftk4E3IfS

