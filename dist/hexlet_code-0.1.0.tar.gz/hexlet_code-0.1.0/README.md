### Hexlet tests and linter status:
[![Actions Status](https://github.com/zitaker/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/zitaker/python-project-49/actions)

Закончил на уроке 5, задании 2 - проверка на четные и нечетные числа

