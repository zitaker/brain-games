# !/usr/bin/env python3
from brain_games.greeting_welcome import qwerty

qwerty()

# from pprint import pprint
# import sys
# print(sys.path)


# from .. import greeting_welcome

# import sys
# sys.path.append(r'/python-project-49/brain_games/scripts')
# import scripts.greeting_welcome.py
# import pprint

# import greeting_welcome
# scripts.greeting_welcome.qwerty()