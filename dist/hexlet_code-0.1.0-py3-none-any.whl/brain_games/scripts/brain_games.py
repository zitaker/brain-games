# !/usr/bin/env python3
from brain_games.cli import Welcome_user
def main():
    print('Welcome to the Brain Games!')

if __name__ == '__main__':
    main()


Welcome_user()