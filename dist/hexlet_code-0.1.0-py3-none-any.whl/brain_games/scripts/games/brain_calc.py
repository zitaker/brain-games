# !/usr/bin/env python3
import brain_games.cli
from brain_games.greeting_welcome import name


print(brain_games.greeting_welcome.name)
